#!/usr/bin/env bash
set -euo pipefail
cd /home/kevin/holosoma-core4d-base
export OPENBLAS_NUM_THREADS=1
audit_python=/home/kevin/.holosoma_deps/miniconda3/envs/hsretargeting/bin/python
audit_output=${1:?Supply a NEW output directory}
"$audit_python" -B scripts/run_reference_geometry_round2.py --output "$audit_output"
"$audit_python" -B scripts/finalize_reference_geometry_round2.py --output "$audit_output"
"$audit_python" -B scripts/render_reference_geometry_round2.py --output "$audit_output"
# Copy the reviewed README_CN.md into the new result before packaging.
"$audit_python" -B scripts/package_reference_geometry_round2.py --output "$audit_output"
