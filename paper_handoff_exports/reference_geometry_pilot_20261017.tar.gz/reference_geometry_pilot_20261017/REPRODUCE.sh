#!/usr/bin/env bash
set -euo pipefail
cd /home/kevin/holosoma-core4d-base
audit_python=/home/kevin/.holosoma_deps/miniconda3/envs/hsretargeting/bin/python
# Supply a NEW output directory; source analysis refuses to overwrite.
audit_output=${1:?Supply a new output directory}
"$audit_python" -B scripts/reference_geometry_pilot.py --output "$audit_output"
"$audit_python" -B scripts/finalize_reference_geometry_pilot.py --output "$audit_output"
"$audit_python" -B scripts/render_reference_geometry_pilot.py --output "$audit_output"
"$audit_python" -B scripts/package_reference_geometry_pilot.py --output "$audit_output"
